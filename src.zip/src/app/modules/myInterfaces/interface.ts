export interface MyDetails{
    A4Name: string,
    A4Email: string,
    A4Login: string,
    A4ID: string,
    A4Photo: string
}